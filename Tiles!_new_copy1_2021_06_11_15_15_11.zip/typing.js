var output = "";

var keyPressed = function() {

    if (key.code !== 8 && key.code !== 65535) {
        output += key.toString();
    }
    if (key.code === 8) {
        output = output.slice(0, output.length - 1);
    }
    
};

  show(); {
    
    fill(255, 0, 0);
    text(output, 100, 100);
    text(output + "|", 100, 100);
        
    
    
}
//let rndLogo;
let seconds;
let cars = [];
let backdrop;
let backdrop1;
let select1;
let road;
let img1;
let sNum = 0;
let game1 = false;
let rndLogo = []
let number;
let startTime;
let s;
let gStart;
var NUM_COLS=4;
var NUM_ROWS=4;
var tiles = [];
let drawTiles
let muzac
let rNum
var output = "";
//button to start game 1
//mouseX >= 25 && mouseX <= 115 && mouseY >= 210 && mouseY <= 240)
let mX1 = 25;
let mX2 = 115;
let mY1 = 210;
let mY2 = 240;

var sel = [
  {
    disc: "Do you know you car logos? All north american companies",
    Play: "Play",
  },
  { disc: "Coming soon! Contact cityGames to suggest a topic!", Play: "Soon" },
  { disc: "Coming soon! Contact cityGames to suggest a topic!", Play: "Soon" },
];

function preload(){
    
  soundFormats('mp3', 'ogg');
  muzac = loadSound('9-Elevator-Music-Royalty-Free.mp3');
}

function setup() {
  createCanvas(400, 400);
  //muzac.play();
 number = (floor)(random(1, 10));
  //image
  road = loadImage("image-help-road.jpg");
  backdrop = loadImage("image-help-back.jpg");
  backdrop1 = loadImage("image-help-trans.png");
  select1 = loadImage("image-help-cars.png");
  img1 = loadImage("image-help-soon.jpg");
   rNum = floor(random(1, 4));
   console.log(rNum);
  //TWO RND NUMBER HAVE TO FIX 
  for (var i = 0; i < NUM_COLS; i++) {
    for (var j = 0; j < NUM_ROWS; j++) {
        tiles.push(
        new Tile(i * 63+75, j * 63+80)
        );
    }
    
}


  
  //arrays of possible pictures
  cars.push(loadImage("image- cars- audi.jpg"));
  cars.push(loadImage("image- cars- ford.jpg"));
  cars.push(loadImage("image- cars- honda.jpg"));
  cars.push(loadImage("image- cars- hyundai.jpg"));
  cars.push(loadImage("image- cars- lexus.jpg"));
  cars.push(loadImage("image- cars- mercedes.jpg"));
  cars.push(loadImage("image- cars- subaru.jpg"));
  cars.push(loadImage("image- cars- volkswagon.jpg"));
  cars.push(loadImage("image- cars- chevy.jpg"));
  cars.push(loadImage("image- cars- toyota.jpg"));
  for(let i = 0; i<10; i++){
    rndLogo.push(new Logos());
  } 
}

/*function mousePressed() {
  sNum++;
}
*/
   drawTiles = function() {
    for (let i in tiles) {
        tiles[i].show()
    }
};



var keyPressed = function() {

    if (key.code !== 8 && key.code !== 65535) {
        output += key.toString();
    }
    if (keyCode === BACKSPACE) {
        output = output.slice(0, output.length - 10);
    }
    
};

//MAIN PAGE
function draw() {
  background(220);
  background(backdrop);
  background(backdrop1);
  textSize(40);
  rect(5, 0, 220, 60);
  text("TileGuessr!", 10, 50);
  //selectors
  for (let n = 0; n < sel.length; n++) {
    rect(20 + n * 120, 80, 100, 170);
    textSize(8);
    text(sel[n].disc, 25 + n * 120, 170, 80);
    rect(25 + n * 120, 210, 90, 30);
    textSize(27);
    text(sel[n].Play, 40 + n * 120, 213, 80);
  }
  image(select1, 22, 80, 97, 80);
  image(img1, 142, 80, 97, 80);
  image(img1, 262, 80, 97, 80);

  //selector, changing scenes
  mouseClicked = function () {
    if (mouseX >= mX1 && mouseX <= mX2 && mouseY >= mY1 && mouseY <= mY2) {
      sNum++;
      game1 = true;
    }
    //TEMP
    print(sNum);
  };
  
  //BREAKING IF GAME START
  if (game1) {
    mX1 = 0;
    mX2 = 0;
    mY1 = 0;
    mY2 = 0;
  }else if(!game1){
    let mX1=25;
    let mX2=115;
    let mY1=210;
    let mY2=240;       
  }
  

  //open car logos scene
  if (sNum == 1) { 
    
    rect(25, 210, 90, 30);
    background(road);
    background(backdrop1);
    textSize(40);
    fill(88, 88, 88);
    rect(5, 0, 220, 60);
    fill(255, 255, 255);
    text("TileGuessr!", 10, 50);
    fill(88, 88, 88);
    rect(75, 80, 250, 250);
    fill(28, 28, 28);
    rndLogo[number].show()
    rect(75, 365, 250, 10);
    s = second();
    startTime = s
    gStart = true
    fTime = 0;
    drawTiles();
    
    //keyfunc
    textSize(20);
    fill(255, 255, 255);
    if (game1) {
    if (millis() % 1000 < 500) {
        
        text(output, 100, 360);
        
    } else {
        
        text(output + "|", 100, 360);
        
    }
    

    }
  }
}

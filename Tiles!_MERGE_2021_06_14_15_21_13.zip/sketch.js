//let rndLogo;
let timer = 320
let cars = [];
let backdrop;
let backdrop1;
let bacc
let select1;
let road;
let img1;
let sNum = 0;
let game1 = false;
let htp = false;
let rndLogo = []
let number;
var NUM_COLS=4;
var NUM_ROWS=4;
var tiles = [];
let drawTiles
let muzac
let rNum
let output = "";
let tNum
//button to start game 1
//mouseX >= 25 && mouseX <= 115 && mouseY >= 210 && mouseY <= 240)
let mX1 = 25;
let mX2 = 115;
let mY1 = 210;
let mY2 = 240;

//button for help
let mX1a = 230;
let mX2a = 340;
let mY1a = 2;
let mY2a = 26;

var sel = [
  {
    disc: "Do you know you car logos? All north american companies",
    Play: "Play",
  },
  { disc: "Coming soon! Contact cityGames to suggest a topic!", Play: "Soon" },
  { disc: "Coming soon! Contact cityGames to suggest a topic!", Play: "Soon" },
];

function preload(){
    
  soundFormats('mp3', 'ogg');
  muzac = loadSound('9-Elevator-Music-Royalty-Free.mp3');
}

function setup() {
  

  
  
  createCanvas(400, 400);
  //muzac.play();
 number = (floor)(random(1, 10));
  //image
  road = loadImage("image-help-road.jpg");
  backdrop = loadImage("image-help-back.jpg");
  backdrop1 = loadImage("image-help-trans.png");
  select1 = loadImage("image-help-cars.png");
  img1 = loadImage("image-help-soon.jpg");
  bac= loadImage("image- help- bac.jpg")
   // rNum = floor(random(1, 4));
   // console.log(rNum);
  //TWO RND NUMBER HAVE TO FIX 
  for (var i = 0; i < NUM_COLS; i++) {
    for (var j = 0; j < NUM_ROWS; j++) {
        tiles.push(
        new Tile(i * 63+75, j * 63+80)
        );
    }
    
}


  
  //arrays of possible pictures
  cars.push(loadImage("image- cars- audi.jpg"));
  cars.push(loadImage("image- cars- ford.jpg"));
  cars.push(loadImage("image- cars- honda.jpg"));
  cars.push(loadImage("image- cars- hyundai.jpg"));
  cars.push(loadImage("image- cars- lexus.jpg"));
  cars.push(loadImage("image- cars- mercedes.jpg"));
  cars.push(loadImage("image- cars- subaru.jpg"));
  cars.push(loadImage("image- cars- volkswagon.jpg"));
  cars.push(loadImage("image- cars- chevy.jpg"));
  cars.push(loadImage("image- cars- toyota.jpg"));
  for(let i = 0; i<10; i++){
    rndLogo.push(new Logos());
  } 
}

/*function mousePressed() {
  sNum++;
}
*/
   drawTiles = function() {
    for (let i in tiles) {
        tiles[i].show()
    }
};


//FOR KEYSnlk
var keyPressed = function() {

    if (key.code !== 8 && key.code !== 65535) {
        output += key.toString();
    }
    if (keyCode === BACKSPACE) {
        output = output.slice(0, output.length - 10);
    }
    
};





//MAIN PAGE

function draw() {
  
  if (sNum == 0){
  background(220);
  background(backdrop);
  background(backdrop1);
  textSize(40);
  fill(255,255,255)
  rect(5, 0, 220, 60);
  fill(0,0,0)
  text("TileGuessr!", 10, 50);
  //selectors
  for (let n = 0; n < sel.length; n++) {
    fill(255,255,255)
    rect(20 + n * 120, 80, 100, 170);
    textSize(8);
    fill(0,0,0)
    text(sel[n].disc, 25 + n * 120, 170, 80);
    fill(255,255,255)
    rect(25 + n * 120, 210, 90, 30);
    textSize(27);
    fill(0,0,0)
    text(sel[n].Play, 40 + n * 120, 213, 80);
  }
  image(select1, 22, 80, 97, 80);
  image(img1, 142, 80, 97, 80);
  image(img1, 262, 80, 97, 80);
   // print(mouseX+"x")
   // print(mouseY+"y")
  
  //how to play
}
  
  
      //back to home

  //selector, changing scenes
  mouseClicked = function () {
    if (mouseX >= 5 && mouseX <= 222 && mouseY >= 0 && mouseY <= 55) {
      sNum = 0;
      game1 = false
      htp = false
        
    }
    if (mouseX >= mX1 && mouseX <= mX2 && mouseY >= mY1 && mouseY <= mY2 ) {
      sNum = 1;
      game1 = true;
    }
    //TEMP
    print(sNum);
    //how to play
      if (mouseX >= mX1a && mouseX <= mX2a && mouseY >= mY1a && mouseY <= mY2a && !htp) {
      sNum = 10;
      htp = true
    }

  };
  
  // print(mouseX+"x")
  // print(mouseY +"Y")
  fill(255,255,255,100)
      rect(230,5,110,27)
      rect(230,35,110,25)
  fill(0,0,0)
  textSize(20)
  text("How to play",230,29)
  
  //BREAKING IF GAME START
  if (game1) {
    mX1 = 0;
    mX2 = 0;
    mY1 = 0;
    mY2 = 0;
  }else if(!game1){
    let mX1=25;
    let mX2=115;
    let mY1=210;
    let mY2=240;       
  }
  
    if (htp) {
    mX1a = 0;
    mX2a = 0;
    mY1a = 0;
    mY2a = 0;
  }else if(!htp){
  let mX1a = 230;
  let mX2a = 340;
  let mY1a = 2;
  let mY2a = 26;      
  }
  
  
  

  //open car logos scene
  if (sNum == 1) { 
    //timer
      if (frameCount % 60 == 0 && timer > 0) {
      timer --;
  }

    rect(25, 210, 90, 30);
    background(road);
    background(backdrop1);
    textSize(40);
    fill(88, 88, 88);
    rect(5, 0, 220, 60);
    fill(255, 255, 255);
    text("TileGuessr!", 10, 50);
    fill(88, 88, 88);
    rect(75, 80, 250, 250);
    fill(28, 28, 28);
    //get random logo and display
    rndLogo[number].show()
    
    fill(88,88,88,30)
    rect(75, 340, 250, 30);
    gStart = true
    drawTiles();
    
    //keyfunc
    textSize(20);
    fill(255, 255, 255);
    if (game1) {
    if (millis() % 1000 < 500) {
        
        text(output, 100, 360);
        
    } else {
        
        text(output + "|", 100, 360);
        
    }
      fill(88,88,88,100)
      rect(230,5,110,27)
      rect(230,35,110,25)
          textSize(20);
      fill(255,255,255)
      
      text("TIME: "+timer, 235, 29);
      text("ROUND: 0",235,58)

    }
    
    
      if(timer == 320){
       tNum = (floor)(random(1, 16));
   
     tiles[tNum].update()
      tiles[tNum].h = 0
  }
//
    if(number == 0 && output == audi){
      print("LEts go")
    }
    
    
}
    
  
  //help scrn
 if (sNum == 10) { 

  background(220);
  background(bac)
  textSize(40);
  fill(255,255,255,100)
  rect(230,5,110,27)
  rect(230,35,110,25)
  fill(255,255,255,88)
  rect(5, 0, 220, 60);
  fill(0,0,0)
  text("TileGuessr!", 10, 50);
  fill(255,255,255,88)
  rect(50,100,300,250)
  textSize(23)
  fill(0,0,0)
  text("Bing J", 230, 30)
//ps to get back click on tileguessr
    
 
 }
}

//

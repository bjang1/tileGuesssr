function setup() {
  createCanvas(400, 400);

var NUM_COLS=3;
var NUM_ROWS=3;

var tiles = [];



var Tile = function(x, y) {
    this.x = x;
    this.y = y;
    this.size = 50;
    this.label = "";
};

Tile.prototype.draw = function() {
    fill(214, 247, 202);
    strokeWeight(2);
    rect(this.x, this.y, this.size, this.size, 10);
    textSize(100);
};


for (var i = 0; i < NUM_COLS; i++) {
    for (var j = 0; j < NUM_ROWS; j++) {
        tiles.push(new Tile(i * 50+100, j * 50));
    }
    
}

var drawTiles = function() {
    for (var i in tiles) {
        tiles[i].draw();
    }
};


draw = function() {
    background(143, 143, 143);
    drawTiles();
};

}

/*function draw() {
  background(220);
}*/
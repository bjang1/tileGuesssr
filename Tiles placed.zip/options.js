/*
Our reff
rect(75, 80, 250, 250);
*/

class Logos{
  constructor(){
  this.rndLogo = cars[Math.floor(Math.random() * cars.length)];
  }
  
show(){
  image(this.rndLogo,75,80, 250, 250) 
  }
  
  }

class Tile {
    constructor(x,y) {
    this.x = x;
    this.y = y;
    this.size = 85;
    this.label = "";
}



  show() {
    fill(255, 255, 255);
    strokeWeight(2);
    rect(this.x, this.y, this.size, this.size );
    textSize(100);
}
}

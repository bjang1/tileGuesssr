let tiles
class tile{
  constructor(img){
    
  }
  
}
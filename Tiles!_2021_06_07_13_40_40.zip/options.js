/*
Our reff
rect(75, 80, 250, 250);
*/
class logos{
  constructor(){
  this.rndLogo = cars[Math.floor(Math.random() * cars.length)];
  }
  
show(){
  rndLogo()
  }
  }
